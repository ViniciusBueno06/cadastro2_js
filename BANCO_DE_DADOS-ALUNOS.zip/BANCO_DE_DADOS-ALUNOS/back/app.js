const express = require('express')
const cors = require('cors')
const mysql = require ('mysql2/promise')
const bodyParser = require ('body-parser')

const app = express()
app.use(cors())
const porta = 3000
app.use(bodyParser.json())

app.listen(porta, ()=>{
    console.log(`Servidor está rodando http://localhost:${porta}`)
})

const pool = mysql.createPool({
    host: `localhost`, 
    user:`root`, 
    password: '',
    database: `db_node`,
    waitForConnections:true,
    connectionLimit:3,
    queueLimit: 0
})
app.get('/api/usuarios', async (req, res)=>{
    try {
        const conexao = await pool.getConnection()
        const sql = "SELECT * FROM usuarios"
        const [linhas] = await conexao.execute(sql)
        conexao.release()
        res.json(linhas)

    } catch(error) {
        console.log(`O Erro que ocorreu foi :${error}`)
        res.send(500).json({error:"Deu algum erro na busca"})
    }
})
 app.get('/api/usuarios/id:id', async (req, res)=>{
    try {
        const id = req.params.id
        const conexao = await pool.getConnection()
        const sql = `SELECT * FROM usuarios WHERE id = ${id} ` 
        const [linhas] = await conexao.execute(sql)
        conexao.release()
        res.json(linhas)

    } catch(error) {
        console.log(`O Erro que ocorreu foi :${error}`)
        res.send(500).json({error:"Deu algum erro na busca"})
    }
 })

 app.get('/api/usuarios/nome/:nome', async (req, res)=>{
    try {
        const nome_passado = req.params.nome
        const conexao = await pool.getConnection()
        const sql = `SELECT * FROM usuarios WHERE nome LIKE "%${nome_passado}%"`
        const [linhas] = await conexao.execute(sql)
        conexao.release()
        res.json(linhas)

    } catch(error) {
        console.log(`O Erro que ocorreu foi :${error}`)
        res.send(500).json({error:"Deu algum erro na busca"})
    }
 })
 app.get('/api/usuarios/email/:email', async(req, res)=>{
    try {
        const email = req.params.email
        const conexao = await pool.getConnection()
        const sql = `SELECT * FROM usuarios WHERE nome LIKE "%${email}}%"`
        const [linhas] = await conexao.execute(sql)
        conexao.release()
        res.json(linhas)

    } catch(error) {
        console.log(`O Erro que ocorreu foi :${error}`)
        res.send(500).json({error:"Deu algum erro na busca"})
    }
 })